package com.aswdc.food_dictionary

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
