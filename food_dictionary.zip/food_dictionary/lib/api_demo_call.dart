import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class apidemo extends StatefulWidget {
  const apidemo({Key? key}) : super(key: key);

  @override
  State<apidemo> createState() => _apidemoState();
}

class _apidemoState extends State<apidemo> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation:10,
        title: Text('API CALL', style: TextStyle(color: Colors.black,)),
      ),
      body: FutureBuilder<Map<String,dynamic>>(builder:(context, snapshot){
        if(snapshot.data != null && snapshot.hasData){
          return ListView.builder(itemBuilder:(context, index) {
            return Card(child:Text(snapshot.data!['country'][index]['probability'].toString()),);
          },itemCount:snapshot.data!['country'].length);
        }else{
          return Center(child: CircularProgressIndicator());
        }
      },future:callApi(),),
    );
  }
    Future<Map<String,dynamic>> callApi() async {
      http.Response res = await http.get(Uri.parse("https://api.nationalize.io/?name=nathaniel"));
     Map<String,dynamic> map = jsonDecode(res.body.toString());
     return map;
    }
  }
