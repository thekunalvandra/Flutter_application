import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:food_dictionary/screen_2.dart';

class S1 extends StatelessWidget {
  const S1({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/image/login2.jpg'),
            fit: BoxFit.cover,
          )),
      child: Scaffold(
        backgroundColor: Colors.white54,
        body: Stack(
          children: [
            Center(
              child: Container(
                decoration: BoxDecoration(boxShadow: [
                  BoxShadow(
                    color: Colors.white,
                    offset: const Offset(
                      4.0,
                      0.0,
                    ),
                    blurRadius: 100.0,
                    spreadRadius: 40.0,
                  ),
                ]),
                padding: EdgeInsets.only(top: 200),
                child: GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => S9()),
                    );
                  },
                  child: Container(
                    width: 300,
                    height: 50,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(50),
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                            blurRadius: 10.0,
                            spreadRadius: 1.0,
                          )
                        ]),
                    child: Center(
                      child: Text(
                        'Sign Up',
                        style: TextStyle(
                          fontSize: 18,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.only(left: 35, top: 280),
              child: const Text(
                'Food dictionary',
                style: TextStyle(
                  color: Colors.deepOrange,
                  fontSize: 40,
                  fontFamily: 'Schyler',
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.only(left: 28, top: 350),
              child: Text(
                ' Cooking Just Got Easier.',
                style: TextStyle(
                  color: Colors.black54,
                  fontSize: 25,
                ),
              ),
            ),
            Center(
              child: Container(
                padding: EdgeInsets.only(top: 340),
                child: GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => S8()),
                    );
                  },
                  child: Container(
                    width: 300,
                    height: 50,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(50),
                        color: Colors.deepOrange,
                        boxShadow: [
                          BoxShadow(
                            blurRadius: 10.0,
                            spreadRadius: 1.0,
                          )
                        ]),
                    child: Center(
                      child: Text(
                        'Sign In',
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Center(
              child: Container(
                  padding: EdgeInsets.only(top: 500),
                  child: Text(
                    'Forgot Password?',
                    style: TextStyle(
                      fontSize: 15,
                      color: Colors.black45,
                    ),
                  )),
            ),
            Center(
              child: Container(
                padding: EdgeInsets.only(top: 630),
                child: Text(
                  'By signing up, you agree with our',
                  style: TextStyle(
                    fontSize: 15,
                    color: Colors.black,
                  ),
                ),
              ),
            ),
            Center(
              child: Container(
                  padding: EdgeInsets.only(top: 680),
                  child: Text(
                    'Terms and Conditions',
                    style: TextStyle(
                      fontSize: 17,
                      color: Colors.deepOrange,
                    ),
                  )),
            )
          ],
        ),
      ),
    );
  }
}

class S8 extends StatefulWidget {
  @override
  State<S8> createState() => _S8State();
}
class _S8State extends State<S8> {
  var formKey = GlobalKey<FormState>();

  bool isRememberMe = true;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/image/login4.jpg'),
            fit: BoxFit.cover,
          )),
      child: Scaffold(
        appBar:AppBar(
          leading:BackButton(color:Colors.white70),
          backgroundColor: Colors.transparent,
          elevation:0,
        ),
        backgroundColor: Colors.transparent,
        body: Stack(
          children: [
            Container(
              padding: EdgeInsets.only(left: 45,top:15),
              child: Text(
                'Food Dictionary',
                style: TextStyle(
                  color: Colors.white,
                  fontSize:40,
                  fontFamily: 'Schyler',
                ),
              ),
            ),
            Container(
              padding:EdgeInsets.only(top:100,left:40,right:40),
              child: SingleChildScrollView(
                  child: Container(
                    decoration:BoxDecoration(color:Colors.white70,borderRadius: BorderRadius.circular(30)),
                    padding: EdgeInsets.only(
                        top: MediaQuery
                            .of(context)
                            .size
                            .height * 0.25,
                        right: 50,
                        left: 50),
                    child: Form(
                      key: formKey,
                      child: Column(
                        children: [
                          TextFormField(
                            decoration: InputDecoration(
                              hintText: 'Username',
                            ),
                            validator: (value) {
                              if (value == null) {
                                return 'Enter UserName';
                              }
                              if (value.length < 6) {
                                return 'Enter valid UserName';
                              }
                            },
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          TextFormField(
                            cursorColor: Colors.deepOrange,
                            obscureText: true,
                            obscuringCharacter: '*',
                            decoration: InputDecoration(
                              hintText: 'Password',
                            ),
                            validator: (value) {
                              if (value == null) {
                                return 'Enter Password';
                              }
                              if (value.length < 5) {
                                return 'Enter valid Password';
                              }
                            },
                          ),
                          SizedBox(
                            height: 30,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              SizedBox(
                                child: Checkbox(
                                  materialTapTargetSize:
                                  MaterialTapTargetSize.shrinkWrap,
                                  value: isRememberMe,
                                  onChanged: (value) {
                                    setState(() {
                                      isRememberMe = !isRememberMe;
                                      print('isRememberMe ::: $isRememberMe');
                                    });
                                  },
                                ),
                                height: 23,
                                width: 23,
                              ),
                              Text('Remember Me',
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold)),
                            ],
                          ),
                          SizedBox(
                            height: 50,
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                child: GestureDetector(
                                    onTap: () {
                                      if (formKey.currentState!.validate()) {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) => const S2()),
                                        );
                                      }
                                    },
                                    child: Container(
                                      width: 300,
                                      height: 50,
                                      decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(50),
                                          color: Colors.deepOrange,
                                          boxShadow: [
                                            BoxShadow(
                                              blurRadius:15.0,
                                              spreadRadius:0.0,
                                            )
                                          ]),
                                      child: Center(
                                        child: Text(
                                          'Sign In',
                                          style: TextStyle(
                                            fontSize: 18,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                    )
                                ),
                              ),
                              SizedBox(
                                height:50,
                              )
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class S9 extends StatefulWidget {
  @override
  State<S9> createState() => _S9State();
}
class _S9State extends State<S9> {
  var formKey = GlobalKey<FormState>();

  bool isRememberMe = true;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/image/login4.jpg'),
            fit: BoxFit.cover,
          )),
      child: Scaffold(
        appBar:AppBar(
          leading:BackButton(color:Colors.white70),
          backgroundColor: Colors.transparent,
          elevation:0,
        ),
        backgroundColor: Colors.transparent,
        body: Stack(
          children: [
            Container(
              padding: EdgeInsets.only(left:45,top:20),
              child: Text(
                'Food Dictionary',
                style: TextStyle(
                  color: Colors.white,
                  fontSize:40,
                  fontFamily: 'Schyler',
                ),
              ),
            ),
            Container(
              padding:EdgeInsets.only(top:100,left:40,right:40),
              child: SingleChildScrollView(
                child: Container(
                  decoration:BoxDecoration(color:Colors.white70,borderRadius: BorderRadius.circular(30)),
                  padding: EdgeInsets.only(
                      top: MediaQuery
                          .of(context)
                          .size
                          .height * 0.20,
                      right: 60,
                      left: 50),
                  child: Form(
                    key: formKey,
                    child: Column(
                      children: [
                        TextFormField(
                          decoration: InputDecoration(
                            hintText: 'Gmail',
                          ),
                          validator: (value) {
                            if (value == null) {
                              return 'Enter Gmail';
                            }
                            if (value.length < 6) {
                              return 'Enter valid UserName';
                            }
                            if (value.characters=='@') {
                              return 'Enter valid Gmail';
                            }
                          },
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        TextFormField(

                          decoration: InputDecoration(
                            hintText: 'Username',
                          ),
                          validator: (value) {
                            if (value == null) {
                              return 'Enter UserName';
                            }
                            if (value.length < 6) {
                              return 'Enter valid UserName';
                            }
                          },
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        TextFormField(
                          cursorColor: Colors.deepOrange,
                          obscureText: true,
                          obscuringCharacter: '*',
                          decoration: InputDecoration(
                            hintText: 'Password',
                          ),
                          validator: (value) {
                            if (value == null) {
                              return 'Enter Password';
                            }
                            if (value.length < 5) {
                              return 'Enter valid Password';
                            }
                          },
                        ),
                        SizedBox(
                          height: 30,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            SizedBox(
                              child: Checkbox(
                                materialTapTargetSize:
                                MaterialTapTargetSize.shrinkWrap,
                                value: isRememberMe,
                                onChanged: (value) {
                                  setState(() {
                                    isRememberMe = !isRememberMe;
                                    print('isRememberMe ::: $isRememberMe');
                                  });
                                },
                              ),
                              height: 23,
                              width: 23,
                            ),
                            Text('Remember Me',
                                style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold)),
                          ],
                        ),
                        SizedBox(
                          height: 50,
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              child: GestureDetector(
                                  onTap: () {
                                    if (formKey.currentState!.validate()) {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(builder: (context) => const S2()),
                                      );
                                    }
                                  },
                                  child: Container(
                                    width:350,
                                    height: 50,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(50),
                                        color: Colors.deepOrange,
                                        boxShadow: [
                                          BoxShadow(
                                            blurRadius: 30.0,
                                            spreadRadius: 0.0,
                                          )
                                        ]),
                                    child: Center(
                                      child: Text(
                                        'Sign Up',
                                        style: TextStyle(
                                          fontSize: 18,
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                  )
                              ),
                            ),
                            SizedBox(
                              height:50,
                            )
                          ],
                        )
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
