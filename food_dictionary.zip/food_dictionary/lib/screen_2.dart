import 'package:flutter/material.dart';
import 'package:food_dictionary/Database/user_list_page.dart';
import 'package:food_dictionary/api/api_demo.dart';
import 'package:food_dictionary/screen_3.dart';
import 'screen_1.dart';

class S2 extends StatelessWidget {
  const S2({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Padding(
          padding: EdgeInsets.symmetric(horizontal: 10),
          child: Builder(
            builder: (context) => IconButton(
              icon: Image.asset(
                "assets/image/menu.png",
                height: 100,
                width: 100,
              ),
              onPressed: () => Scaffold.of(context).openDrawer(),
            ),
          ),
        ),
        actions: [
          Container(
            padding: EdgeInsets.only(right: 20),
            child: GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const S10()),
                );
              },
              child: CircleAvatar(
                  backgroundImage: AssetImage('assets/image/login1.jpeg')),
            ),
          ),
        ],
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: false,
        titleSpacing: 0,
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.deepOrange,
              ),
              child: Text(
                'Food\nDictionary',
                style: TextStyle(
                  fontSize: 38,
                  fontFamily: 'Schyler',
                ),
              ),
            ),
            ListTile(
              leading: Icon(
                Icons.car_repair,
              ),
              title: const Text('page1'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => S8()),
                );
              },
            ),
            ListTile(
              leading: Icon(
                Icons.car_repair,
              ),
              title: const Text('page2'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => S9()),
                );
              },
            ),
            ListTile(
              leading: Icon(
                Icons.question_mark,
              ),
              title: const Text('About'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => S11()),
                );
              },
            ),
            SizedBox(
              height: 20,
            ),
            ListTile(
              leading: Icon(
                Icons.data_thresholding_outlined,
              ),
              title:
                  const Text('Database Demo', style: TextStyle(fontSize: 25)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => user_list_page()),
                );
              },
            ),
            SizedBox(
              height:20,
            ),
            ListTile(
              leading: Icon(
                Icons.data_thresholding_outlined,
              ),
              title:
              const Text('Api Demo', style: TextStyle(fontSize: 25)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => api_demo()),
                );
              },
            ),
          ],
        ),
      ),
      body: Container(
        child: ListView(
          scrollDirection: Axis.vertical,
          children: [
            Container(
              padding: EdgeInsets.only(left: 20, top: 20),
              child: Text(
                'Category',
                style: TextStyle(
                    fontSize: 35,
                    color: Colors.black,
                    fontWeight: FontWeight.bold),
              ),
            ),
            Container(
              padding: EdgeInsets.only(left: 23, top: 10),
              child: Text(
                'Popular',
                style: TextStyle(fontSize: 20, color: Colors.black),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const S3()),
                );
              },
              child: Container(
                margin: EdgeInsetsDirectional.all(10),
                height: 250,
                width: 200,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(25)),
                    image: DecorationImage(
                        image: AssetImage('assets/image/item1.jpg'),
                        fit: BoxFit.cover)),
                child: Container(
                    decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Colors.black, Colors.transparent],
                          begin: Alignment.bottomCenter,
                          end: Alignment.topCenter,
                        ),
                        borderRadius: BorderRadius.all(Radius.circular(25))),
                    padding: EdgeInsets.only(left: 23, top: 210),
                    child: Text(
                      'Aloo Paratha',
                      style: TextStyle(
                        fontSize: 25,
                        color: Colors.white,
                      ),
                    )),
              ),
            ),
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const S4()),
                );
              },
              child: Container(
                margin: EdgeInsetsDirectional.all(10),
                height: 250,
                width: 200,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(25)),
                  image: DecorationImage(
                      image: AssetImage('assets/image/item2.jpg'),
                      fit: BoxFit.cover),
                ),
                child: Container(
                    decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Colors.black, Colors.transparent],
                          begin: Alignment.bottomCenter,
                          end: Alignment.topCenter,
                        ),
                        borderRadius: BorderRadius.all(Radius.circular(25))),
                    padding: EdgeInsets.only(left: 23, top: 210),
                    child: Text(
                      'Pav Bhaji',
                      style: TextStyle(fontSize: 25, color: Colors.white),
                    )),
              ),
            ),
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const S5()),
                );
              },
              child: Container(
                margin: EdgeInsetsDirectional.all(10),
                height: 250,
                width: 200,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(25)),
                  image: DecorationImage(
                      image: AssetImage('assets/image/item3.jpg'),
                      fit: BoxFit.cover),
                ),
                child: Container(
                    decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Colors.black, Colors.transparent],
                          begin: Alignment.bottomCenter,
                          end: Alignment.topCenter,
                        ),
                        borderRadius: BorderRadius.all(Radius.circular(25))),
                    padding: EdgeInsets.only(left: 23, top: 210),
                    child: Text(
                      'Vada Pav',
                      style: TextStyle(fontSize: 25, color: Colors.white),
                    )),
              ),
            ),
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const S6()),
                );
              },
              child: Container(
                margin: EdgeInsetsDirectional.all(10),
                height: 250,
                width: 200,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(25)),
                  image: DecorationImage(
                      image: AssetImage('assets/image/item4.jpg'),
                      fit: BoxFit.cover),
                ),
                child: Container(
                    decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Colors.black, Colors.transparent],
                          begin: Alignment.bottomCenter,
                          end: Alignment.topCenter,
                        ),
                        borderRadius: BorderRadius.all(Radius.circular(25))),
                    padding: EdgeInsets.only(left: 23, top: 210),
                    child: Text(
                      'Samosa',
                      style: TextStyle(fontSize: 25, color: Colors.white),
                    )),
              ),
            ),
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const S7()),
                );
              },
              child: Container(
                margin: EdgeInsetsDirectional.all(10),
                height: 250,
                width: 200,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(25)),
                  image: DecorationImage(
                      image: AssetImage('assets/image/item5.jpg'),
                      fit: BoxFit.cover),
                ),
                child: Container(
                    decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Colors.black, Colors.transparent],
                          begin: Alignment.bottomCenter,
                          end: Alignment.topCenter,
                        ),
                        borderRadius: BorderRadius.all(Radius.circular(25))),
                    padding: EdgeInsets.only(left: 23, top: 210),
                    child: Text(
                      'Pani Puri',
                      style: TextStyle(fontSize: 25, color: Colors.white),
                    )),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class S10 extends StatelessWidget {
  const S10({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          image: DecorationImage(
              image: AssetImage('assets/image/login1.jpeg'),
              fit: BoxFit.cover)),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Stack(
          children: [
            Container(
              child: Center(
                child: Container(
                    height: 550,
                    width: 200,
                    color: Colors.black54,
                    child: CircleAvatar(
                      backgroundImage: AssetImage('assets/image/login1.jpeg'),
                      radius: 100,
                    )),
              ),
            ),
            Center(
              child: Container(
                padding: EdgeInsets.only(
                  top: 250,
                ),
                child: Text(
                  'Gmail',
                  style: TextStyle(color: Colors.white, fontSize: 25),
                ),
              ),
            ),
            Center(
              child: Container(
                padding: EdgeInsets.only(
                  top: 350,
                ),
                child: Text(
                  'Username',
                  style: TextStyle(color: Colors.white, fontSize: 25),
                ),
              ),
            ),
            Center(
              child: Container(
                padding: EdgeInsets.only(
                  top: 450,
                ),
                child: Text(
                  'Password',
                  style: TextStyle(color: Colors.white, fontSize: 25),
                ),
              ),
            )
          ],
        ),
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          leading: BackButton(),
          backgroundColor: Colors.transparent,
          elevation: 0,
        ),
      ),
    );
  }
}
