class EmployeesListModel {
  EmployeesListModel({
      String? foodname, 
      String? foodimage, 
      String? contact, 
      String? id,}){
    _foodname = foodname;
    _foodimage = foodimage;
    _contact = contact;
    _id = id;
}

  EmployeesListModel.fromJson(dynamic json) {
    _foodname = json['foodname'];
    _foodimage = json['foodimage'];
    _contact = json['contact'];
    _id = json['id'];
  }
  String? _foodname;
  String? _foodimage;
  String? _contact;
  String? _id;
EmployeesListModel copyWith({  String? foodname,
  String? foodimage,
  String? contact,
  String? id,
}) => EmployeesListModel(  foodname: foodname ?? _foodname,
  foodimage: foodimage ?? _foodimage,
  contact: contact ?? _contact,
  id: id ?? _id,
);
  String? get foodname => _foodname;
  String? get foodimage => _foodimage;
  String? get contact => _contact;
  String? get id => _id;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['foodname'] = _foodname;
    map['foodimage'] = _foodimage;
    map['contact'] = _contact;
    map['id'] = _id;
    return map;
  }

}