import 'package:food_dictionary/Database/model/employees_list_model/EmployeesListModel.dart';
class EmployeesModel{
  List <EmployeesListModel>? _resultList;
  EmployeesModel({
    List<EmployeesListModel>? resulLtist,
  }) {
    _resultList = resultList;
  }
  List<EmployeesListModel>? get resultList => _resultList;
  EmployeesModel.fromJson(dynamic json) {
    if (json != null) {
      _resultList = [];
      json.forEach((v) {
        _resultList!.add(EmployeesListModel.fromJson(v));
      });
    }
  }
}