import 'package:flutter/material.dart';
import 'package:sliding_sheet/sliding_sheet.dart';

import 'screen_1.dart';

class S3 extends StatelessWidget {
  const S3({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        leading: BackButton(),
        actions: [
          Builder(
            builder: (context) => IconButton(
              icon: Image.asset(
                "assets/image/menu.png",
                height: 100,
                width: 100,
              ),
              onPressed: () => Scaffold.of(context).openEndDrawer(),
            ),
          ),
        ],
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      endDrawer: Drawer(
        child: ListView(
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.deepOrange,
              ),
              child: Text('Food\nDictionary',style:TextStyle(
                fontSize:38,
                fontFamily: 'Schyler',
              ),),
            ),
            ListTile(
              leading: Icon(
                Icons.car_repair,
              ),
              title: const Text('page1'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => S8()),
                );
              },
            ),
            ListTile(
              leading: Icon(
                Icons.car_repair,
              ),
              title: const Text('page2'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => S9()),
                );
              },
            ),
            ListTile(
              leading: Icon(
                Icons.question_mark,
              ),
              title: const Text('About'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => S11()),
                );
              },
            ),
          ],
        ),
      ),
      body: SlidingSheet(
        elevation:15,
        cornerRadius:15,
        snapSpec: const SnapSpec(
          snap: true,
          snappings: [0.1,1.0,1.0],
          positioning: SnapPositioning.relativeToAvailableSpace,
        ),
        parallaxSpec: ParallaxSpec(enabled:true,amount:1),
        body: Center(
          child: Image.asset(
            'assets/image/item1.jpg',
            fit: BoxFit.cover,
            height: double.maxFinite,
          ),
        ),
        builder: (context, state) {
          return Container(
            height:300,
            child:Center(
              child: Column(
                children: [
                  Container(
                    width:60,
                    height:30,
                    decoration:BoxDecoration(image: DecorationImage(image: AssetImage('assets/image/menu2.png'))),
                  ),
                  Text('Aloo Paratha',style:TextStyle(fontSize:50,fontWeight:FontWeight.bold,),),
                  Text('It is traditionally eaten for breakfast.\nIt is made using unleavened dough rolled with a mixture of mashed potato and spices (amchur, garam masala,)\nwhich is cooked on a hot tawa with butter or ghee.\nAloo paratha is usually served with butter, chutney, curd, or Indian pickles.',
                    style:TextStyle(fontSize:20,fontWeight:FontWeight.bold,),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
    //
  }
}
class S4 extends StatelessWidget {
  const S4({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        leading: BackButton(),
        actions: [
          Builder(
            builder: (context) => IconButton(
              icon: Image.asset(
                "assets/image/menu.png",
                height: 100,
                width: 100,
              ),
              onPressed: () => Scaffold.of(context).openEndDrawer(),
            ),
          ),
        ],
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      endDrawer: Drawer(
        child: ListView(
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.deepOrange,
              ),
              child: Text('Food\nDictionary',style:TextStyle(
                fontSize:38,
                fontFamily: 'Schyler',
              ),),
            ),
            ListTile(
              leading: Icon(
                Icons.car_repair,
              ),
              title: const Text('page1'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => S8()),
                );
              },
            ),
            ListTile(
              leading: Icon(
                Icons.car_repair,
              ),
              title: const Text('page2'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => S9()),
                );
              },
            ),
            ListTile(
              leading: Icon(
                Icons.question_mark,
              ),
              title: const Text('About'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => S11()),
                );
              },
            ),
          ],
        ),
      ),
      body: SlidingSheet(
        elevation:15,
        cornerRadius:15,
        snapSpec: const SnapSpec(
          snap: true,
          snappings: [0.1,1.0,1.0],
          positioning: SnapPositioning.relativeToAvailableSpace,
        ),
        parallaxSpec: ParallaxSpec(enabled:true,amount:1),
        body: Center(
          child: Image.asset(
            'assets/image/item2.jpg',
            fit: BoxFit.cover,
            height: double.maxFinite,
          ),
        ),
        builder: (context, state) {
          return Container(
            height:300,
            child:Center(
              child: Column(
                children: [
                  Container(
                    width:60,
                    height:30,
                    decoration:BoxDecoration(image: DecorationImage(image: AssetImage('assets/image/menu2.png'))),
                  ),
                  Text('Pav Bhaji',style:TextStyle(fontSize:50,fontWeight:FontWeight.bold,),),
                  Text('Pav bhaji is a spiced mixture of mashed vegetables in a thick gravy served with bread. Vegetables in the curry may commonly include potatoes, onions, carrots, chillies, peas, bell peppers and tomatoes. Street sellers usually cook the curry on a flat griddle (tava) and serve the dish hot. A soft white bread roll is the usual accompaniment to the curry, but this does not preclude the use of other bread varieties such as chapati, roti or brown bread.',
                    style:TextStyle(fontSize:18,fontWeight:FontWeight.bold,),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
class S5 extends StatelessWidget {
  const S5({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        leading: BackButton(),
        actions: [
          Builder(
            builder: (context) => IconButton(
              icon: Image.asset(
                "assets/image/menu.png",
                height: 100,
                width: 100,
              ),
              onPressed: () => Scaffold.of(context).openEndDrawer(),
            ),
          ),
        ],
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      endDrawer: Drawer(
        child: ListView(
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.deepOrange,
              ),
              child: Text('Food\nDictionary',style:TextStyle(
                fontSize:38,
                fontFamily: 'Schyler',
              ),),
            ),
            ListTile(
              leading: Icon(
                Icons.car_repair,
              ),
              title: const Text('page1'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => S8()),
                );
              },
            ),
            ListTile(
              leading: Icon(
                Icons.car_repair,
              ),
              title: const Text('page2'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => S9()),
                );
              },
            ),
            ListTile(
              leading: Icon(
                Icons.question_mark,
              ),
              title: const Text('About'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => S11()),
                );
              },
            ),
          ],
        ),
      ),
      body: SlidingSheet(
        elevation:15,
        cornerRadius:15,
        snapSpec: const SnapSpec(
          snap: true,
          snappings: [0.1,1.0,1.0],
          positioning: SnapPositioning.relativeToAvailableSpace,
        ),
        parallaxSpec: ParallaxSpec(enabled:true,amount:1),
        body: Center(
          child: Image.asset(
            'assets/image/item3.jpg',
            fit: BoxFit.cover,
            height: double.maxFinite,
          ),
        ),
        builder: (context, state) {
          return Container(
            height:300,
            child:Center(
              child: Column(
                children: [
                  Container(
                    width:60,
                    height:30,
                    decoration:BoxDecoration(image: DecorationImage(image: AssetImage('assets/image/menu2.png'))),
                  ),
                  Text('Vada Pav',style:TextStyle(fontSize:50,fontWeight:FontWeight.bold,),),
                  Text('A boiled potato is mashed and mixed with chopped green chilli and garlic, mustard seeds, and spices (usually asafoetida and turmeric). The mass is then shaped into a ball, dipped into gram flour batter and deep fried. The resultant fritter is served by placing inside a bread bun, accompanied with one or more chutneys and fried green chilli.',
                    style:TextStyle(fontSize:20,fontWeight:FontWeight.bold,),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
class S6 extends StatelessWidget {
  const S6({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        leading: BackButton(),
        actions: [
          Builder(
            builder: (context) => IconButton(
              icon: Image.asset(
                "assets/image/menu.png",
                height: 100,
                width: 100,
              ),
              onPressed: () => Scaffold.of(context).openEndDrawer(),
            ),
          ),
        ],
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      endDrawer: Drawer(
        child: ListView(
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.deepOrange,
              ),
              child: Text('Food\nDictionary',style:TextStyle(
                fontSize:38,
                fontFamily: 'Schyler',
              ),),
            ),
            ListTile(
              leading: Icon(
                Icons.car_repair,
              ),
              title: const Text('page1'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => S8()),
                );
              },
            ),
            ListTile(
              leading: Icon(
                Icons.car_repair,
              ),
              title: const Text('page2'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => S9()),
                );
              },
            ),
            ListTile(
              leading: Icon(
                Icons.question_mark,
              ),
              title: const Text('About'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => S11()),
                );
              },
            ),
          ],
        ),
      ),
      body: SlidingSheet(
        elevation:15,
        cornerRadius:15,
        snapSpec: const SnapSpec(
          snap: true,
          snappings: [0.1,1.0,1.0],
          positioning: SnapPositioning.relativeToAvailableSpace,
        ),
        parallaxSpec: ParallaxSpec(enabled:true,amount:1),
        body: Center(
          child: Image.asset(
            'assets/image/item4.jpg',
            fit: BoxFit.cover,
            height: double.maxFinite,
          ),
        ),
        builder: (context, state) {
          return Container(
            height:400,
            child:Center(
              child: Column(
                children: [
                  Container(
                    width:60,
                    height:30,
                    decoration:BoxDecoration(image: DecorationImage(image: AssetImage('assets/image/menu2.png'))),
                  ),
                  Text('Samosa',style:TextStyle(fontSize:50,fontWeight:FontWeight.bold,),),
                  Text('The samosa is prepared with an all-purpose flour and stuffed with a filling, often a mixture of diced and cooked or mashed boiled potato , onions, green peas, lentils, ginger, spices and green chili.A samosa can be vegetarian or non-vegetarian, depending on the filling. The entire pastry is deep-fried in vegetable oil or rarely ghee to a golden brown. It is served hot, often with fresh green chutney, such as mint, coriander, or tamarind. It can also be prepared in a sweet form. Samosas are often served in chaat, along with the traditional accompaniments of either a chickpea or a white pea preparation, served with yogurt, tamarind paste and green chutney, garnished with chopped onions, coriander, and chaat masala.',
                    style:TextStyle(fontSize:17,fontWeight:FontWeight.bold,),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
class S7 extends StatelessWidget {
  const S7({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        leading: BackButton(),
        actions: [
          Builder(
            builder: (context) => IconButton(
              icon: Image.asset(
                "assets/image/menu.png",
                height: 100,
                width: 100,
              ),
              onPressed: () => Scaffold.of(context).openEndDrawer(),
            ),
          ),
        ],
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      endDrawer: Drawer(
        child: ListView(
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.deepOrange,
              ),
              child: Text('Food\nDictionary',style:TextStyle(
                fontSize:38,
                fontFamily: 'Schyler',
              ),),
            ),
            ListTile(
              leading: Icon(
                Icons.car_repair,
              ),
              title: const Text('page1'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => S8()),
                );
              },
            ),
            ListTile(
              leading: Icon(
                Icons.car_repair,
              ),
              title: const Text('page2'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => S9()),
                );
              },
            ),
            ListTile(
              leading: Icon(
                Icons.question_mark,
              ),
              title: const Text('About'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => S11()),
                );
              },
            ),
          ],
        ),
      ),
      body: SlidingSheet(
        elevation:15,
        cornerRadius:15,
        snapSpec: const SnapSpec(
          snap: true,
          snappings: [0.1,1.0,1.0],
          positioning: SnapPositioning.relativeToAvailableSpace,
        ),
        parallaxSpec: ParallaxSpec(enabled:true,amount:1),
        body: Center(
          child: Image.asset(
            'assets/image/item5.jpg',
            fit: BoxFit.cover,
            height: double.maxFinite,
          ),
        ),
        builder: (context, state) {
          return Container(
            height:350,
            child:Center(
              child: Column(
                children: [
                  Container(
                    width:60,
                    height:30,
                    decoration:BoxDecoration(image: DecorationImage(image: AssetImage('assets/image/menu2.png'))),
                  ),
                  Text('Pani Puri',style:TextStyle(fontSize:50,fontWeight:FontWeight.bold,),),
                  Text('Panipuri consists of a round hollow puri (a deep-fried crisp flatbread), filled with a mixture of flavored water (known as imli pani), tamarind chutney, chili powder, chaat masala, potato mash, onion, or chickpeas.Fuchka (or fuska or puska) differs from panipuri in content and taste. It uses spiced mashed potatoes as the filling. It is tangy rather than sweetish while the water is sour and spicy.',
                    style:TextStyle(fontSize:20,fontWeight:FontWeight.bold,),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
class S11 extends StatelessWidget {
  const S11({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration:BoxDecoration(image:DecorationImage(image:AssetImage('assets/image/login1.jpeg'),fit:BoxFit.cover)),
      child:Scaffold(
        backgroundColor:Colors.black38,
        body:Stack(
          children: [
            Container(
              padding:EdgeInsets.only(top:100,left:40),
              child:Text(
                'Food Dictionary',
                style:TextStyle(color:Colors.white,fontSize:40,fontFamily:'Schyler'),
              ),
            ),
            Container(
              padding:EdgeInsets.only(top:180,left:40),
              child:Text(
                'About:',
                style:TextStyle(color:Colors.white,fontSize:30,fontFamily:'Schyler'),
              ),
            ),
            Container(
              padding:EdgeInsets.only(top:300,left:40,right:30),
              child:Text(
                'Food dictionary is the dictionary that defines you what is variety of the Indian Cuisine,',
                style:TextStyle(color:Colors.white,fontSize:25,fontFamily:'Schyler'),
              ),
            ),
            Container(
              padding:EdgeInsets.only(top:450,left:40,right:30),
              child:Text(
                'Food dictionary will contain all the Indian dishes which are famous for there taste.',
                style:TextStyle(color:Colors.white,fontSize:25,fontFamily:'Schyler'),
              ),
            ),

          ],
        ),
        extendBodyBehindAppBar: true,
        appBar:AppBar(
          leading: BackButton(),
          backgroundColor:Colors.transparent,
          elevation:0,
        ),
      ),
    );
  }
}