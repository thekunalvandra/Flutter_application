import 'package:flutter/material.dart';
import 'package:food_dictionary/screen_1.dart';
import 'package:food_dictionary/screen_2.dart';
import 'package:food_dictionary/screen_3.dart';
import 'package:flutter/services.dart';
import 'api/api_demo.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner:false,
    initialRoute: 'screen_1',
    routes: {'screen_1':(context) =>S1()},
  ));
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    initialRoute: '/',
    routes: {
      '/': (context) => const S1(),
      '/2': (context) => const S2(),
      '/3': (context) => const S3(),
      '/4': (context) => const S4(),
      '/5': (context) => const S5(),
      '/6': (context) => const S6(),
      '/7': (context) => const S7(),
      '/8': (context) => S8(),
      '/9': (context) => S9(),
      '/10': (context) => S10(),
      '/11': (context) => S11(),
    },
  ));
}

